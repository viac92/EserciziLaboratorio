./cut 3 10 lorem.input
./cut 1 15 costituzione.input
./cut 70 100 lorem.input
