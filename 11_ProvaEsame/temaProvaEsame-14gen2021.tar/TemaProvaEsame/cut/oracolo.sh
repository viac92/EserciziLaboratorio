cut -c$1-$2 $3
